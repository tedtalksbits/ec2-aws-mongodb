// create a schema for a bank account

import mongoose from 'mongoose';

const accountSchema = new mongoose.Schema(
    {
        preferenceId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Preference',
        },
        bills: {
            type: Array,
            default: [],
        },
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
    },
    { timestamps: true }
);

export default mongoose.model('Account', accountSchema);
