// types for req and res

import { Request, Response } from 'express';

export const account = (_req: Request, res: Response) => {
    // console.log(req.cookies);
    res.send('Account was hit');
};
